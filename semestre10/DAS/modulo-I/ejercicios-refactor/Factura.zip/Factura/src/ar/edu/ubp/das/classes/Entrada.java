package ar.edu.ubp.das.classes;

public class Entrada {

	public Tarifa 	tarifa;
	public int    	horaDesde;
	public int		horaHasta;
	public double	costo;
	
}
