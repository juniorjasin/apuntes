package ar.edu.ubp.das.alumnos;

public class Alumno extends Docente {
    
    public int getNroLegAlumno() {
        return nroLegAlumno;
    }

    public void setNroLegAlumno(int nroLegAlumno) {
        this.nroLegAlumno = nroLegAlumno;
    }
    
}
