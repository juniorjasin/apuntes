package ar.edu.ubp.das.formas;

public abstract class Forma {
    public abstract double getPerimetro();
    public abstract double getArea();
}
