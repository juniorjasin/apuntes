package ar.edu.ubp.das.classes;

public class Jugador {
	
    private int ganados;
    
	public int getGanados() {
		return ganados;
	}

	public void setGanados(int ganados) {
		this.ganados = ganados;
	}

}
