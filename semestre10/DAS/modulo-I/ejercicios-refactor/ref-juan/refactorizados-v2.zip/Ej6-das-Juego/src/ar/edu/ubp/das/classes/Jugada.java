package ar.edu.ubp.das.classes;

public abstract class Jugada {
	public abstract int contra(Jugada jugada);
}
