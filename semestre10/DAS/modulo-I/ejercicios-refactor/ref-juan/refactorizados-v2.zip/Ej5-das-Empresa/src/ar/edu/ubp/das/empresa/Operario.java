package ar.edu.ubp.das.empresa;

public class Operario extends Cargo {
	public String getNombreCargo() {
		return "OPERARIO";
	}
}
