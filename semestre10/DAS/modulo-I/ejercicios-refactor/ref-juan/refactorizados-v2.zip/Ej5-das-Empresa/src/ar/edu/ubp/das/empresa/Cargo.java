package ar.edu.ubp.das.empresa;

public class Cargo {
	public int getJerarquiaCargo() {
		return 10;
	}
	
	public String getNombreCargo() {
		return "DEFAULT";
	}
}
