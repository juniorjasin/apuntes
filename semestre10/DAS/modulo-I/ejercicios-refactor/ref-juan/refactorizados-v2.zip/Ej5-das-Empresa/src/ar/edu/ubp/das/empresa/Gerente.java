package ar.edu.ubp.das.empresa;

public class Gerente extends Cargo {
	public int getJerarquiaCargo() {
		return 40;
	}

	public String getNombreCargo() {
		return "GERENTE";
	}
}
