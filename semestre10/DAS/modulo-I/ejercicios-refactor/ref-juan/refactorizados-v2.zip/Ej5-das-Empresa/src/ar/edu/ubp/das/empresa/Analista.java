package ar.edu.ubp.das.empresa;

public class Analista extends Cargo {
	public int getJerarquiaCargo() {
		return 30;
	}
	
	public String getNombreCargo() {
		return "ANALISTA";
	}
}
