package ar.edu.ubp.das.empresa;

public class Contable extends Cargo {
	public int getJerarquiaCargo() {
		return 20;
	}
	
	public String getNombreCargo() {
		return "CONTABLE";
	}
}
