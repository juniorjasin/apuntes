class Person {

    public String _name;
    
    //...
} 