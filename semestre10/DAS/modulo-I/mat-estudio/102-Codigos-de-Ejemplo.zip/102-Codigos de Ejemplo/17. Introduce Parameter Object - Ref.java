class Frame {

	private int x;
	private int y;
	private int height;
	private int width;

	// ...

}

public void drawRectangle(Frame frame) {
	// ...
}

public void drawEllipse(Frame frame) {
	// ...
}

public void drawStar(Frame frame) {
	// ...
}
