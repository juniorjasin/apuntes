public void calculateAreaOfCircle(double radius) {
    double area = Math.PI * Math.pow(radius, 2);
    System.out.println ("Area: " + area);
}
