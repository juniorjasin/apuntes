public void setHeight(int arg) {
	_height = arg;
}

public void setWidth (int arg) {
	_width = arg;
}