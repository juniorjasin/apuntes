double shippingCost = calculateShipping(order);


public double calculateShipping(Order order) {
	// ...
}