public void drawRectangle(int x, int y, int height, int width) {
	// ...
}

public void drawEllipse(int x, int y, int height, int width) {
	// ...
}

public void drawStar(int x, int y, int height, int width) {
	// ...
}
