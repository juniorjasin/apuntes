class Person {

	private String _name;

	public String getName() {
		return this._name;
	}

	public void setName(String arg) {
		this._name = arg;
	}

	//...
}